const shareButtons = document.querySelectorAll('.tile-share-button')
console.log(shareButtons)


function copyText(e) {
//prevent button going to the site
e.preventDefault()
const link = this.getAttribute('link')
console.log(link)
}

shareButtons.forEach(shareButtons => shareButtons.addEventListener('click', copyText))